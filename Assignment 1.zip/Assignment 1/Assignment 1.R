install.packages("psych", dependencies = TRUE)
library("psych") # pairs.panels, cor.ci

setwd("C:/MyDocs/Dropbox/Dev/R Projects/R Intro/Assignment 1")

##### Before we start modelling, let's analyse data
#     Read all of the WB indicators into a data frame
#     Get sample vectors (as follows) and explore them
wb.agriland <- read.csv(file="API_AG.LND.AGRI.ZS_DS2_en_csv_v2.csv", skip=4, header=TRUE)
wb.cropprod <- read.csv(file="API_AG.PRD.CROP.XD_DS2_en_csv_v2.csv", skip=4, header=TRUE)
wb.foodprod <- read.csv(file="API_AG.PRD.FOOD.XD_DS2_en_csv_v2.csv", skip=4, header=TRUE)
wb.fdi <- read.csv(file="API_BX.KLT.DINV.CD.WD_DS2_en_csv_v2.csv", skip=4, header=TRUE)   # foreign direct investment
wb.airpoll <- read.csv(file="API_EN.ATM.PM25.MC.ZS_DS2_en_csv_v2.csv", skip=4, header=TRUE)
#wb.invtrans <- read.csv(file="API_IE.PPI.TRAN.CD_DS2_en_csv_v2.csv", skip=4, header=TRUE)  # investment in transport with private participation
wb.airtrans <- read.csv(file="API_IS.AIR.DPRT_DS2_en_csv_v2.csv", skip=4, header=TRUE)
#wb.raillines <- read.csv(file="API_IS.RRS.TOTL.KM_DS2_en_csv_v2.csv", skip=4, header=TRUE)
wb.internet <- read.csv(file="API_IT.NET.USER.P2_DS2_en_csv_v2.csv", skip=4, header=TRUE)
wb.gdpcap <- read.csv(file="API_NY.GDP.PCAP.CD_DS2_en_csv_v2.csv", skip=4, header=TRUE)  # gdp per capita
#wb.youthlitr <- read.csv(file="API_SE.ADT.1524.LT.ZS_DS2_en_csv_v2.csv", skip=4, header=TRUE)
wb.adultlitr <- read.csv(file="API_SE.ADT.LITR.FE.ZS_DS2_en_csv_v2.csv", skip=4, header=TRUE)
#wb.enrprsc <- read.csv(file="API_SE.ENR.PRSC.FM.ZS_DS2_en_csv_v2.csv", skip=4, header=TRUE)
#wb.prevhiv <- read.csv(file="API_SH.DYN.AIDS.ZS_DS2_en_csv_v2.csv", skip=4, header=TRUE)
#wb.spsurgwork <- read.csv(file="API_SH.MED.SAOP.P5_DS2_en_csv_v2.csv", skip=4, header=TRUE)  # specialist surgical workforce
wb.healthexp <- read.csv(file="API_SH.XPD.TOTL.ZS_DS2_en_csv_v2.csv", skip=4, header=TRUE)
wb.empfserv <- read.csv(file="API_SL.SRV.EMPL.FE.ZS_DS2_en_csv_v2.csv", skip=4, header=TRUE)  # employement of female in services
wb.lfexpbirth <- read.csv(file="API_SP.DYN.LE00.IN_DS2_en_csv_v2.csv", skip=4, header=TRUE)  # life expectancy at birth
#wb.teenmom <- read.csv(file="API_SP.MTR.1519.ZS_DS2_en_csv_v2.csv", skip=4, header=TRUE)  #teenage mother
wb.mobcelsubs <- read.csv(file="API_IT.CEL.SETS.P2_DS2_en_csv_v2.csv", skip=4, header=TRUE)
wb.Greenhousegas <- read.csv(file="API_EN.ATM.GHGT.KT.CE_DS2_en_csv_v2.csv", skip=4, header=TRUE)
wb.watersrvcs <- read.csv(file="API_SH.H2O.SAFE.ZS_DS2_en_csv_v2.csv", skip=4, header=TRUE)
wb.sanitationfclts <- read.csv(file="API_SH.STA.ACSN.UR_DS2_en_csv_v2.csv", skip=4, header=TRUE)
wb.militaryexp <- read.csv(file="API_MS.MIL.XPND.GD.ZS_DS2_en_csv_v2.csv", skip=4, header=TRUE)
wb.secureintrnt <- read.csv(file="API_IT.NET.SECR.P6_DS2_en_csv_v2.csv", skip=4, header=TRUE)
#wb.researchersrnd <- read.csv(file="API_SP.POP.SCIE.RD.P6_DS2_en_csv_v2.csv", skip=4, header=TRUE)

plot(density(wb.agriland$X2012, na.rm = TRUE))
plot(density(wb.cropprod$X2012, na.rm = TRUE))
plot(density(wb.foodprod$X2012, na.rm = TRUE))
plot(density(wb.fdi$X2012, na.rm = TRUE))
plot(density(wb.airpoll$X2012, na.rm = TRUE))
#plot(density(wb.invtrans$X2012, na.rm = TRUE))
plot(density(wb.airtrans$X2012, na.rm = TRUE))
#plot(density(wb.raillines$X2012, na.rm = TRUE))
plot(density(wb.internet$X2012, na.rm = TRUE))
plot(density(wb.gdpcap$X2012, na.rm = TRUE))
#plot(density(wb.youthlitr$X2012, na.rm = TRUE))
plot(density(wb.adultlitr$X2012, na.rm = TRUE))
#plot(density(wb.enrprsc$X2012, na.rm = TRUE))
#plot(density(wb.prevhiv$X2012, na.rm = TRUE))
#plot(density(wb.spsurgwork$X2012, na.rm = TRUE))
plot(density(wb.healthexp$X2012, na.rm = TRUE))
plot(density(wb.empfserv$X2012, na.rm = TRUE))
plot(density(wb.lfexpbirth$X2012, na.rm = TRUE))
#plot(density(wb.teenmom$X2012, na.rm = TRUE))
plot(density(wb.mobcelsubs$X2012, na.rm = TRUE))
plot(density(wb.Greenhousegas$X2012, na.rm = TRUE))
plot(density(wb.watersrvcs$X2012, na.rm = TRUE))
plot(density(wb.sanitationfclts$X2012, na.rm = TRUE))
plot(density(wb.militaryexp$X2012, na.rm = TRUE))
plot(density(wb.secureintrnt$X2012, na.rm = TRUE))
#plot(density(wb.researchersrnd$X2012, na.rm = TRUE))

agriland <- wb.agriland$X2012
cropprod <- wb.cropprod$X2012
foodprod <- wb.foodprod$X2012
fdi <- wb.fdi$X2012
airpoll <- wb.airpoll$X2012
#invtrans <- wb.invtrans$X2012
airtrans <- wb.airtrans$X2012
#raillines <- wb.raillines$X2012
internet <- wb.internet$X2012
gdpcap <- wb.gdpcap$X2012
#youthlitr <- wb.youthlitr$X2012
adultlitr <- wb.adultlitr$X2012
#enrprsc <- wb.enrprsc$X2012
#prevhiv <- wb.prevhiv$X2012
#spsurgwork <- wb.spsurgwork$X2012
healthexp <- wb.healthexp$X2012
empfserv <- wb.empfserv$X2012
lfexpbirth <- wb.lfexpbirth$X2012
#teenmom <- wb.teenmom$X2012
mobcelsubs <- wb.mobcelsubs$X2012
Greenhousegas <- wb.Greenhousegas$X2012
watersrvcs <- wb.watersrvcs$X2012
sanitationfclts <- wb.sanitationfclts$X2012
militaryexp <- wb.militaryexp$X2012
secureintrnt <- wb.secureintrnt$X2012
#researchersrnd <- wb.researchersrnd$X2012

all.2012 <- data.frame(
  agriland,
  cropprod,
  foodprod,
  fdi,
  airpoll,
  airtrans,
  internet,
  empfserv,
  healthexp,
  adultlitr,
  mobcelsubs,
  watersrvcs,
  sanitationfclts,
  militaryexp,
  secureintrnt,
  lfexpbirth,
  gdpcap,
  Greenhousegas
  )

summary(all.2012)
View(all.2012)
pairs.panels(all.2012, col="red")

### a) Let's start by replacing all NAs with 0.
all.2012.na.zeros <- all.2012
all.2012.na.zeros[is.na(all.2012.na.zeros)] <- 0
summary(all.2012.na.zeros)
pairs.panels(all.2012.na.zeros, col="red")

## adult literacy aand female employ rejected

### d) Let's try replacing all NAs with the mean of each row, any issues?

rm.agriland <- rowMeans(wb.agriland[,-c(1:34)], na.rm = TRUE)
rm.cropprod <- rowMeans(wb.cropprod[,-c(1:34)], na.rm = TRUE)
rm.foodprod <- rowMeans(wb.foodprod[,-c(1:34)], na.rm = TRUE)
rm.fdi <- rowMeans(wb.fdi[,-c(1:34)], na.rm = TRUE)
rm.airpoll <- rowMeans(wb.airpoll[,-c(1:34)], na.rm = TRUE)
rm.airtrans <- rowMeans(wb.airtrans[,-c(1:34)], na.rm = TRUE)
rm.secureintrnt <- rowMeans(wb.secureintrnt[,-c(1:34)], na.rm = TRUE)
rm.healthexp <- rowMeans(wb.healthexp[,-c(1:34)], na.rm = TRUE)
rm.mobcelsubs <- rowMeans(wb.mobcelsubs[,-c(1:34)], na.rm = TRUE)
rm.watersrvcs <- rowMeans(wb.watersrvcs[,-c(1:34)], na.rm = TRUE)
rm.sanitationfclts <- rowMeans(wb.sanitationfclts[,-c(1:34)], na.rm = TRUE)
rm.militaryexp <- rowMeans(wb.militaryexp[,-c(1:34)], na.rm = TRUE)
rm.internet <- rowMeans(wb.internet[,-c(1:34)], na.rm = TRUE)
rm.lfexpbirth <- rowMeans(wb.lfexpbirth[,-c(1:34)], na.rm = TRUE)
rm.gdpcap <- rowMeans(wb.gdpcap[,-c(1:34)], na.rm = TRUE)
rm.Greenhousegas <- rowMeans(wb.Greenhousegas[,-c(1:34)], na.rm = TRUE)

# Let us create a data frame of all indicator row means
all.na.rowmeans <- data.frame(
  rm.agriland,
  rm.cropprod,
  rm.foodprod,
  rm.fdi,
  rm.airpoll,
  rm.airtrans, 
  rm.secureintrnt,
  rm.healthexp, 
  rm.mobcelsubs, 
  rm.watersrvcs, 
  rm.sanitationfclts,
  rm.militaryexp,
  rm.internet, 
  rm.lfexpbirth,
  rm.gdpcap,
  rm.Greenhousegas
)

# See the statistics and correlations
View(all.na.rowmeans)
summary(all.na.rowmeans)
pairs.panels(all.na.rowmeans, col="red")

# Now we can eliminate NaNs with column means as before
for(i in 1:ncol(all.na.rowmeans)){
  all.na.rowmeans[is.nan(all.na.rowmeans[,i]), i] <- 
    mean(all.na.rowmeans[,i], na.rm = TRUE)
}
summary(all.na.rowmeans)
pairs.panels(all.na.rowmeans, col="red")


### Can we do better than this?
### e) Yes, we could use the existing row data to create a predictive model,
###    such as linear regression, and then predict even future data, e.g. in 2020!
### f) However, we should always consider not using variables with too many NAs!!!
###    Note that because litr has over 30% (actually 80%) of NAs
###    it should have never been used, so delete it!


##### Let us normalise all variables the best we could
#   Choices we have:
#   a) Do nothing - very important, often better than anything else
#   b) Target heavily skewed - may have no impact on regression, better not but optional
#      If you decided to transform it then your predictions need to be untransformed
#   c) Predictors heavily skewed - if the reason is in the units being different then OK
#   d) In regression you'd do it much later if errors are skewed and not values
#
# Useful site: https://www.desmos.com/calculator

# Note that all indicators are %, except for co2em which are metric tonnes per capita
# We could try to trasform it to better match the units of the remaning variables

all.transformed <- all.na.rowmeans
all.transformed$rm.Greenhousegas <- all.transformed$rm.Greenhousegas ^ (1 / 6)
pairs.panels(all.transformed, col="red")

# If you have a lot of variables a more compact view is preferred
# You can also use this method to find out how much you can trust correlations (p-value)
cor.ci(all.transformed)

### Remove variables which have little impact on the dependent variable
#   Also remove all correlated independent variables (between themselves)

all.selected <- subset(all.transformed, select = -c(rm.Greenhousegas, rm.gdpcap, rm.internet, rm.militaryexp, rm.watersrvcs, rm.airtrans, rm.mobcelsubs,rm.cropprod,rm.secureintrnt))
pairs.panels(all.selected, col="red")
cor.ci(all.selected)

# Can densities explain relationships?

plot(density(all.selected$rm.lfexpbirth))
plot(density(all.selected$rm.sanitationfclts))
plot(density(all.selected$rm.healthexp))


# Can scatterplots explain relationships?

plot(x=all.selected$rm.sanitationfclts, y=all.selected$rm.lfexpbirth,
     xlab="Sanitation Facilities", ylab = "Life Expectancy",
     col="red", main="Sanitation vs Life Exp (1960-2015)")
abline(h = mean(all.selected$rm.lfexpbirth), col="blue")

plot(x=all.selected$rm.airpoll, y=all.selected$rm.lfexpbirth,
     xlab="Air Pollution", ylab = "Life Expectancy",
     col="red", main="Air Pollution vs Life Exp (1960-2015)")
abline(h = mean(all.selected$rm.lfexpbirth), col="blue")
